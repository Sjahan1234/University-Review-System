<?php

    $con = mysqli_connect("localhost","root","","university_review_system");

    if(!$con){
        die("Connection Error");
    }
?>